from gendiff.diff_builder import generate_diff
from gendiff.cli import parse_args


__all__ = ('generate_diff', 'parse_args')
