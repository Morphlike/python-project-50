#!/usr/bin/env python3
from .. import cli


def main():
    cli.parse_args()
    


if __name__ == '__main__':
    main()
