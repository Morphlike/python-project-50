### Hexlet tests and linter status:
[![Actions Status](https://github.com/Morphlike/python-project-50/workflows/hexlet-check/badge.svg)](https://github.com/Morphlike/python-project-50/actions)
[![Maintainability](https://api.codeclimate.com/v1/badges/efa33dd6f00c54bd09b3/maintainability)](https://codeclimate.com/github/Morphlike/python-project-50/maintainability)
[![Test Coverage](https://api.codeclimate.com/v1/badges/efa33dd6f00c54bd09b3/test_coverage)](https://codeclimate.com/github/Morphlike/python-project-50/test_coverage)